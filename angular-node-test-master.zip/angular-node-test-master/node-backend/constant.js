const Config ={ 
    PORT:3500,
    MONGO_DB_URL:'mongodb://rama1234:rama1234@cluster0-shard-00-00-fwo6s.mongodb.net:27017,cluster0-shard-00-01-fwo6s.mongodb.net:27017,cluster0-shard-00-02-fwo6s.mongodb.net:27017/UserDB?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true',
    AUTH_TOKEN:'abcdxyz@123'
};
 module.exports = Config